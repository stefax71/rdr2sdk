﻿#include "UIPrompt.h"

#include "../../../inc/natives.h"

UIPromptBuilder* UIPromptBuilder::with_mode(const AutoFill autofill_mode)
{
    this->prompt_mode_ = hud::AUTO_FILL;
    this->fill_time_ms = autofill_mode.fill_time_ms;
    this->num_mashes = autofill_mode.num_mashes;
    return this;
}

UIPromptBuilder* UIPromptBuilder::with_mode(const PressOrRelease pressed_or_released)
{
    if (pressed_or_released.pressed)
    {
        this->prompt_mode_ = hud::EPromptMode::PRESS;
    }
    else
    {
        this->prompt_mode_ = hud::EPromptMode::RELEASE;
    }
    return this;
}

UIPrompt* UIPromptBuilder::build()
{
    int handle_ = HUD::_UI_PROMPT_REGISTER_BEGIN();
    auto* internal_prompt_ = new UIPrompt(handle_);

    const char* hash = MISC::_CREATE_VAR_STRING(10, "LITERAL_STRINGH", prompt_text.c_str());
    HUD::_UI_PROMPT_SET_TEXT(handle_, hash);
    
    HUD::_UI_PROMPT_SET_CONTROL_ACTION(handle_, this->input_type_);

    if (this->associated_entity > 0)
    {
        unsigned long entity_group = HUD::_UI_PROMPT_GET_GROUP_ID_FOR_TARGET_ENTITY(associated_entity);
        if (entity_group > 0)
        {
            HUD::_UI_PROMPT_SET_GROUP(handle_, entity_group, 0);
        }
    }

    switch (prompt_mode_)
    {
    case hud::PRESS:
        HUD::_UI_PROMPT_SET_STANDARD_MODE(handle_, true);
        break;
    case hud::RELEASE:
        HUD::_UI_PROMPT_SET_STANDARD_MODE(handle_, true);
        break;
    default:
        break;
    }

    HUD::_UI_PROMPT_SET_PRIORITY(handle_, this->priority_);
    HUD::_UI_PROMPT_SET_TRANSPORT_MODE(handle_, this->transport_mode_);
    HUD::_UI_PROMPT_SET_ATTRIBUTE(handle_, 18, true);
    HUD::_UI_PROMPT_REGISTER_END(handle_);

    return internal_prompt_;
}
