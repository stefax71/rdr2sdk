﻿#pragma once

#include <string>

#include "../RDREnums.h"
#include "../../../inc/types.h"
#include "../../../inc/natives.h"


enum EInputType: unsigned long;
enum EPromptMode: unsigned long;

struct AutoFill
{
    int fill_time_ms;
    int num_mashes;
};

struct PressOrRelease
{
    bool pressed;
};

class UIPrompt
{
private:
    long handle_;
    bool visible {false};
    bool enabled {false};

    
public:
    explicit UIPrompt(long handle)
        : handle_(handle)
    {
    }
    
    FORCEINLINE void set_visible(bool visible) { this->visible = visible; HUD::_UI_PROMPT_SET_VISIBLE(handle_, visible); }
    FORCEINLINE void set_enabled(bool enabled) { this->enabled = enabled; HUD::_UI_PROMPT_SET_ENABLED(handle_, enabled); }    

    bool operator==(const UIPrompt& other) const
    {
        return handle_ == other.handle_;
    }
    
    operator Prompt() const
    {
        return this->handle_;
    }
    
    
};

class UIPromptBuilder
{
private:
    std::string prompt_text;
    hud::EInputType input_type_;
    hud::EPromptMode prompt_mode_;
    int priority_ {3};
    Entity associated_entity;
    
    hud::ETransportMode transport_mode_ {hud::ETransportMode::ETM_ANY}; // Can be ANY, ON_FOOT, IN_VEHICLE
    
    int attribute {18};
    int fill_time_ms;
    int num_mashes;

public:
    UIPromptBuilder() {
    };

    UIPromptBuilder* with_input_type(const hud::EInputType input) { this->input_type_ = input; return this;}
    UIPromptBuilder* with_text(const char* text) { this->prompt_text = text; return this;}
    UIPromptBuilder* with_priority(const int priority) { this->priority_ = priority; return this; }
    UIPromptBuilder* with_transport_mode(hud::ETransportMode transport_mode) { this->transport_mode_ = transport_mode; return this; }
    UIPromptBuilder* with_mode(const AutoFill autofill_mode);
    UIPromptBuilder* with_mode(const PressOrRelease pressed_or_released);
    UIPromptBuilder* associated_to_entity(Entity entity) { this->associated_entity = entity; return this; }
    // UIPromptBuilder* with_mode(EPromptMode mode);
    UIPrompt* build();
        
};

